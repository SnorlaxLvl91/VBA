\pagenumbering{gobble}

To cite R in publications use:

  R Core Team (2018). R: A language and environment for statistical computing. R
  Foundation for Statistical Computing, Vienna, Austria. URL

  https://www.R-project.org/.

A BibTeX entry for LaTeX users is

```
  @Manual{,
    title = {R: A Language and Environment for Statistical Computing},
    author = {{R Core Team}},
    organization = {R Foundation for Statistical Computing},
    address = {Vienna, Austria},
    year = {2018},
    url = {https://www.R-project.org/},
  }
```

We have invested a lot of time and effort in creating R, please cite it when
using it for data analysis. See also ‘citation("pkgname")’ for citing R
packages.

\newpage

To cite R in publications use:

  R Core Team (2018). R: A language and environment for statistical computing. R
  Foundation for Statistical Computing, Vienna, Austria. URL

  https://www.R-project.org/.

A BibTeX entry for LaTeX users is

```
  @Manual{,
    title = {R: A Language and Environment for Statistical Computing},
    author = {{R Core Team}},
    organization = {R Foundation for Statistical Computing},
    address = {Vienna, Austria},
    year = {2018},
    url = {https://www.R-project.org/},
  }
```

We have invested a lot of time and effort in creating R, please cite it when
using it for data analysis. See also ‘citation("pkgname")’ for citing R
packages.
